gcc master.c -o master
gcc up_cons.c -o up_cons
gcc up_prod.c -o up_prod
gcc np_prod.c -o np_prod
gcc np_cons.c -o np_cons
gcc s_prod.c -o s_prod
gcc s_cons.c -o s_cons
gcc cb.c -o cb -pthread -lrt

./master

